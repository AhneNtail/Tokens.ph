<?php
    require "DBconnection.php";

    if(isset($_POST['Submit'])){

        $passengerNumber = $_POST['passNo'];

        $query = ("UPDATE `passengerinfo` SET passengerName='$_POST[fullName]',phoneNumber='$_POST[phoneNumber]',email='$_POST[passengerEmail]', password = '$_POST[passengerPassword]' where passengerId='$_POST[passNo]'");
        $query_run = mysqli_query($connectDb,$query);

        if($query_run){
            echo "data added";
        }else
            echo "error";
    }







?>