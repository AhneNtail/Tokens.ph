-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2022 at 04:48 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pasaheroesdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `passengerinfo`
--

CREATE TABLE `passengerinfo` (
  `passengerName` text NOT NULL,
  `phoneNumber` varchar(15) NOT NULL,
  `email` varchar(320) NOT NULL,
  `password` varchar(128) NOT NULL,
  `passengerId` bigint(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `passengerinfo`
--

INSERT INTO `passengerinfo` (`passengerName`, `phoneNumber`, `email`, `password`, `passengerId`) VALUES
('lloydieieieie', '5756757', '4545454@gmail.com', '14214', 1),
('aaaaaa', 'aaaa', 'aaa', 'aaaaa', 2),
('aaaaaaaa', 'aaaaaaaa', 'aaaaa', 'aaaaa', 3),
('asdad', 'adsas', 'adsasd', 'asdad', 4),
('ariel objero', 'asdadas', 'asda', 'asada', 5),
('adsadads', 'adasda', 'asdad', 'adsaa', 6),
('asdadaasd', 'asdasdasd', 'asdada', 'asdasdasd', 7),
('Brian Albao', '12313', 'brianAL@gmail.com', 'albaotest', 8),
('Cherise Pineda', '564123324', 'cheriseP@gmail.com', 'cherisetest', 9),
('aaaaaaaaaaaaaaaa', 'ddddddddd', 'dddddddddd', 'dddddddd', 10),
('Eric Piid', '929454', 'EricP@gmail.com', 'erictest', 11),
('Gian Angelo Dasigan', '1', 'gianmonyo1@gmail.com', 'giantest', 12),
('Hiroyuki Suzuki', '255879532', 'hiro@gmail.com', 'hirotest', 13),
('LLOYYD Obs', '65464564', 'lloydasd@GMAIL.COM', 'ASDASDADS', 14),
('Nathaniel Bomaras', '2147483647', 'nathBomaras@gmail.com', 'nathtest', 15),
('sss', 'sssss', 'ssss', 'ssssss', 16),
('Lloyd Objero', '0', 'xdbruhaaaah@gmail.com', 'lloydtest', 17),
('Yuan Sta.Rosa', '1231232', 'yuanStaR123@gmail.com', 'yuantest', 18),
('LLOYDDDIEE', '87987798', 'LLOYDADSA@GMAIL.COM', '123454', 620000),
('gian dasigan', '1231231', 'gianangelo@gmail.com', '12312312', 273478684),
('lloyyyyyyyyyyd', 'asdasd', 'asdads', 'asdada', 3879026177);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `passengerinfo`
--
ALTER TABLE `passengerinfo`
  ADD PRIMARY KEY (`passengerId`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `passengerinfo`
--
ALTER TABLE `passengerinfo`
  MODIFY `passengerId` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3879026178;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
